public class Main {
    public static void main(String[] args) {
        // Get Singleton instance
        Printer printer1 = Printer.getInstance();
        printer1.printMessage("Hello, Singleton!");

        // Get another instance
        Printer printer2 = Printer.getInstance();
        printer2.printMessage("This is the same printer instance.");

        // Checking if both instances are the same
        System.out.println("Are printer1 and printer2 the same? " + (printer1 == printer2));
    }
}
