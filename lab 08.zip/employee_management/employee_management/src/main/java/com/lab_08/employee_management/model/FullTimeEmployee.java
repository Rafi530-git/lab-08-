package com.lab_08.employee_management.model;

import lombok.Getter;

@Getter
public class FullTimeEmployee implements Employee {
    @Override
    public String getEmployeeType() {
        return "Full-Time Employee";
    }
}
