package com.lab_08.employee_management.model;

import lombok.Getter;

@Getter
public class PartTimeEmployee implements Employee {
    @Override
    public String getEmployeeType() {
        return "Part-Time Employee";
    }
}
