package com.lab_08.employee_management.model;

import lombok.Getter;

@Getter
public class Intern implements Employee {
    @Override
    public String getEmployeeType() {
        return "Intern";
    }
}
