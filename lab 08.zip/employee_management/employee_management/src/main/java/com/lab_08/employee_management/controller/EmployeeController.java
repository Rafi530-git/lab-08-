package com.lab_08.employee_management.controller;

import com.lab_08.employee_management.factory.EmployeeFactory;
import com.lab_08.employee_management.model.Employee;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @GetMapping("/{type}")
    public String getEmployeeType(@PathVariable String type) {
        Employee employee = EmployeeFactory.createEmployee(type);
        return "Created: " + employee.getEmployeeType();
    }
}
