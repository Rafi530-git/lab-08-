package com.lab_08.employee_management.factory;

import com.lab_08.employee_management.model.*;

public class EmployeeFactory {
    public static Employee createEmployee(String type) {
        switch (type.toLowerCase()) {
            case "fulltime":
                return new FullTimeEmployee();
            case "parttime":
                return new PartTimeEmployee();
            case "intern":
                return new Intern();
            default:
                throw new IllegalArgumentException("Invalid employee type: " + type);
        }
    }
}
