package com.lab_08.employee_management.model;

public interface Employee {
    String getEmployeeType();
}
