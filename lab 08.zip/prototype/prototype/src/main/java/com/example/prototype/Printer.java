class Printer {
    // Step 1: Create a private static instance
    private static Printer instance;

    // Step 2: Private constructor to prevent instantiation
    private Printer() {
        System.out.println("Printer instance created!");
    }

    // Step 3: Public method to get the single instance
    public static Printer getInstance() {
        if (instance == null) {
            instance = new Printer(); // Create instance if not already created
        }
        return instance;
    }

    // Step 4: Print message method
    public void printMessage(String message) {
        System.out.println("Printing: " + message);
    }
}
